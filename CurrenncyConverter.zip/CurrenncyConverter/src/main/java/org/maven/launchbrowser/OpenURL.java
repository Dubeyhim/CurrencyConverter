package org.maven.launchbrowser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class OpenURL {
@Test
	public void Currency () throws InterruptedException, IOException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\himdubey\\Desktop\\Automation\\Selenium standalone Jar\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		FileInputStream fi=new FileInputStream("C:\\Users\\himdubey\\Documents\\Test Automation\\CurrenncyConverter\\src\\main\\java\\objectrepository\\object.properties");
		Properties data =new Properties();
		data.load(fi);
        driver.get(data.getProperty("URL"));
        driver.manage().window().maximize();
        driver.findElement(By.xpath(".//div[@class='privacy-basic']//div[2]//button")).click();
		Thread.sleep(3000);
        driver.findElement(By.xpath("//input[@class='Input-lwa9ow-0 AmountField-qk8iiz-0 KTMHL']")).sendKeys("2");;
        Reporter.log("Value.entered");
		driver.findElement(By.xpath("//div[@class='css-upmyww converterform-dropdown__indicator converterform-dropdown__dropdown-indicator']")).click();
        System.out.println(" From Selected");
		
        Thread.sleep(5000);
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//div[@class='css-1wy0on6 converterform-dropdown__indicators']")));
        actions.click();
        actions.sendKeys("EUR",Keys.ENTER);
        actions.build().perform();
        Thread.sleep(3000);
        System.out.println("Pound Selected");
        Actions actions1 = new Actions(driver);
        actions1.moveToElement(driver.findElement(By.xpath("//div[@class='css-upmyww converterform-dropdown__indicator converterform-dropdown__dropdown-indicator']")));
        actions1.click();
        actions1.sendKeys("GBP",Keys.ENTER);
        actions1.build().perform();
        Thread.sleep(3000);
        System.out.println("Pound Selected");
        driver.findElement(By.xpath(".//button[@class='Button-sc-1ikk70s-0 submitButton SubmitButton-sc-6euey0-0 hEIFba']")).click();
        driver.close();
		
		
		
	}

}
