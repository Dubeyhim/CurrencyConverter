---------------Guide to execute program------------

1. Launch Eclipse and select appropriate workspace
2. Click on project CUrrencyConverter
3. Click on src/main/java
4. Click on org.maven.launchbrowser package.
5. Right Click on OpenURL.java class-->RunAs-->TestNg Test
6. After Execution press F5
7. Click on test-output Folder
8. Click on index.html to view the TestNg Report
